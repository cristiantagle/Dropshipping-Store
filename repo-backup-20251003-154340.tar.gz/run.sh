#!/usr/bin/env bash
set -euo pipefail

echo "📦 Respaldando repo antes de commit..."
BACKUP="repo-backup-$(date +%Y%m%d-%H%M%S).tar.gz"
tar --exclude='node_modules' --exclude='.next' --exclude='.git' -czf "$BACKUP" .

restore() {
  echo "⚠️ Error detectado. Restaurando repo desde $BACKUP..."
  tar -xzf "$BACKUP" -C .
  exit 1
}
trap restore ERR

echo "🧹 Asegurando que los .bak estén ignorados..."
if ! grep -q '\.bak' .gitignore; then
  echo "*.bak*" >> .gitignore
  git add .gitignore
fi

echo "➕ Agregando cambios..."
git add -A

echo "💬 Haciendo commit..."
git commit -m "feat: actualizar home con fetch directo desde Supabase (seguro y optimizado)"

echo "🚀 Pusheando a main..."
git push origin main

echo "✅ Cambios integrados en main con éxito."