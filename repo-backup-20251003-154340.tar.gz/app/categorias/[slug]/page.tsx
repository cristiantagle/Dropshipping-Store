import { getProductsByCategory } from "@/lib/products";
import { getCategory } from "@/lib/categorias";

export default async function CategoriaPage({ params }: { params: { slug: string } }) {
  const categoria = await getCategory(params.slug);
  const productos = await getProductsByCategory(params.slug);

  return (
    <main className="max-w-6xl mx-auto px-6 py-10">
      <h1 className="text-2xl font-bold mb-6">{categoria?.nombre || "Categoría"}</h1>
      {productos.length === 0 ? (
        <p className="text-gray-600">No hay productos en esta categoría.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {productos.map((p) => (
            <article key={p.id} className="border rounded-lg p-4">
              <img
                src={p.image_url || "/placeholder.jpg"}
                alt={p.name}
                className="w-full h-48 object-cover mb-2"
              />
              <h2 className="font-semibold">{p.name}</h2>
              <p className="text-sm text-gray-600">{p.description || "Sin descripción"}</p>
              <p className="text-lg font-bold mt-2">
                {Intl.NumberFormat("es-CL", {
                  style: "currency",
                  currency: "CLP",
                  maximumFractionDigits: 0,
                }).format(p.price_cents)}
              </p>
            </article>
          ))}
        </div>
      )}
    </main>
  );
}
