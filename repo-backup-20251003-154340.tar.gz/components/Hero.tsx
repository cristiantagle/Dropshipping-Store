"use client";

import { ShoppingBag } from "lucide-react";

export default function Hero() {
  return (
    <section className="lunaria-parallax relative overflow-hidden mt-16 h-[400px] flex items-center">
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/25 z-0"></div>

      {/* Contenido limitado al ancho de la tienda */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-6 text-center lg:text-left">
        <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-white drop-shadow-xl">
          Descubre productos que <span className="text-lime-300">inspiran</span>
        </h1>
        <p className="mt-4 text-lg text-white/90 drop-shadow-md">
          Tu tienda de confianza para belleza, hogar y más. Calidad real, precios accesibles.
        </p>
        <div className="mt-6 flex justify-center lg:justify-start">
          <a
            href="/categorias"
            className="inline-flex items-center gap-2 bg-lime-500 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:bg-lime-600 transition"
          >
            <ShoppingBag className="w-5 h-5" />
            Explorar categorías
          </a>
        </div>
      </div>
    </section>
  );
}
