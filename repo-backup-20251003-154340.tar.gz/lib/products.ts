import { createClient } from "@supabase/supabase-js";

export type Producto = {
  id: string;
  name: string;
  description: string | null;
  price_cents: number;
  image_url: string | null;
  category_slug: string | null;
  created_at?: string;
};

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function getProductsByCategory(slug: string): Promise<Producto[]> {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .eq("category_slug", slug);

  if (error) {
    console.error("Error fetching products by category:", error);
    return [];
  }
  return data || [];
}

export async function getProductById(id: string): Promise<Producto | null> {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .eq("id", id)
    .single();

  if (error) {
    console.error("Error fetching product by id:", error);
    return null;
  }
  return data;
}

export async function getAllProducts(): Promise<Producto[]> {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching all products:", error);
    return [];
  }
  return data || [];
}
