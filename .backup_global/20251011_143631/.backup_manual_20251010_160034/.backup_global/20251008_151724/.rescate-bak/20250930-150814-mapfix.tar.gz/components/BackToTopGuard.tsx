'use client';
export default function BackToTopGuard() { return null; }
